from distutils.core import setup
setup(name='project_template',
	version='0.1',
	desription="A simple tool to manage your data workflow",
	author="Ivan Kryukov",
	license="WTFUW",
	entry_points = {"console_scripts":["pypt=py-make:main"]},
	py_modules=['project_template'],
)
