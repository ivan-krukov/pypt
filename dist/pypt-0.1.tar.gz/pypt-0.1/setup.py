from setuptools import setup
setup(name='pypt',
	version='0.1',
	description="A simple project template tool to manage your data workflow",
	license="WTFUW",
	scripts = ["pypt/pypt"],
	packages=['pypt'],
)
